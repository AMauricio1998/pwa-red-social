
export interface Pais {
    nombre: string; 
    capital: string; 
    idioma: string; 
    bandera: string; 
  }