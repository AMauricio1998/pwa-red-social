export interface Materia {
    id:number;
    cuatrimestre: number;
    materias:string;
    fecha: string;
    imagen: string;
} 
